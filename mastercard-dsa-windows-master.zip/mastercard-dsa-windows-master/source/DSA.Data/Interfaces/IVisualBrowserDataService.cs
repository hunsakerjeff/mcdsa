﻿namespace DSA.Data.Interfaces
{
    public interface IVisualBrowserDataService
    {
    }
}