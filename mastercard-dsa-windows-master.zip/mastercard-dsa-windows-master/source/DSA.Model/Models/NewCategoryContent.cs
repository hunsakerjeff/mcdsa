﻿namespace DSA.Model.Models
{
    public class NewCategoryContent : CategoryContent
    {
        public new static readonly string SoupName = "NewCategoryContent";
    }
}
