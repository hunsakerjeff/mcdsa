﻿using DSA.Model.Models;

namespace DSA.Model.Dto
{
    public class ContentReviewInfo
    {
        public ContentReview ContentReview { get; set; }

        public MediaLink MediaLink { get; set; }
    }
}
