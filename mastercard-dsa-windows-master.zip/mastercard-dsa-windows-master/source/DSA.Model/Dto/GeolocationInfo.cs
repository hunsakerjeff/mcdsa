﻿namespace DSA.Model.Dto
{
    public class GeolocationInfo
    {
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }
}
