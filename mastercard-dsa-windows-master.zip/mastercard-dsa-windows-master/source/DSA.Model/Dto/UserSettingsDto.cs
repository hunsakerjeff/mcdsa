﻿namespace DSA.Model.Dto
{
    public class UserSettingsDto
    {
        public string UserId { get; set; }
        public string SelectedMobileConfigurationId { get; set; }
    }
}
