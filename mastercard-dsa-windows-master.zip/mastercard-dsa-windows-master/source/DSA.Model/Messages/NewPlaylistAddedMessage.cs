﻿namespace DSA.Model.Messages
{
    public class NewPlaylistAddedMessage
    {
    }
}
