﻿namespace DSA.Model.Messages
{
    public class NewContentAvaliableMessage
    {
    }
}
