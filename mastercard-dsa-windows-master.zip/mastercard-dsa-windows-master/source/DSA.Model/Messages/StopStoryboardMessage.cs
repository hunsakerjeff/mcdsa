﻿namespace DSA.Model.Messages
{
    public class StopStoryboardMessage
    {
        public string StoryboardName { get; set; }
    }
}
