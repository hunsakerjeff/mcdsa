﻿namespace DSA.Model.Messages
{
    public class PlaylistChangedMessage
    {
    }
}
