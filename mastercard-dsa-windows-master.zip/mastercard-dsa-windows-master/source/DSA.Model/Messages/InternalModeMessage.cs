﻿namespace DSA.Model.Messages
{
    public class InternalModeMessage
    {
       public bool IsEnable { get; set; }
    }
}
