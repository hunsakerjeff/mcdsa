﻿namespace DSA.Model.Messages
{
    public class SearchQuerySubmitted
    {
        public string Query { get; set; }
    }
}
