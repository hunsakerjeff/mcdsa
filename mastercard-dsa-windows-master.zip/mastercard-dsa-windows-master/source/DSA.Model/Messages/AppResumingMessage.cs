﻿namespace DSA.Model.Messages
{
    public class AppResumingMessage
    {
        public AppResumingMessage()
        {
        }
    }
}