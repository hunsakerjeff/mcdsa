﻿namespace DSA.Model.Messages
{
    public class StartStoryboardMessage
    {
        public string StoryboardName { get; set; }
        public bool LoopForever { get; set; }
    }
}
