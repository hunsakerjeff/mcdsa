﻿namespace DSA.Model.Messages
{
    public class HistoryChangedMessage
    {
    }
}
