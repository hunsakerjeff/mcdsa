﻿namespace DSA.Model.Messages
{
    public class CheckInOutChangedMessage
    {
    }
}
