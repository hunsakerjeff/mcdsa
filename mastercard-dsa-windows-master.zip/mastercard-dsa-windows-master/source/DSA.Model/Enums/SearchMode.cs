﻿namespace DSA.Model.Enums
{
    public enum SearchMode
    {
        PopulatedInDropDown,
        UseSearchPage
    }
}
