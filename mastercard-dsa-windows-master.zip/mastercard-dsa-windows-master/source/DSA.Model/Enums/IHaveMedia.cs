﻿using DSA.Model.Dto;

namespace DSA.Model.Enums
{
    public interface IHaveMedia
    {
         MediaLink Media { get; }
    }
}
