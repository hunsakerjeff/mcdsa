﻿namespace DSA.Model.Enums
{
    public enum SynchronizationMode
    {
        Full,
        Delta,
        Initial
    }
}