﻿namespace DSA.Model.Enums
{
    public interface IHavePlaylist
    {
         string PlaylistID { get; }
    }
}
