﻿namespace DSA.Shell.Controls.MenuBrowser
{
    public sealed partial class MenuBrowser
    {
        public MenuBrowser()
        {
            InitializeComponent();
        }
    }
}
