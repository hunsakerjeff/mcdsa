﻿namespace DSA.Shell.Controls.Playlist
{
    public sealed partial class PlaylistControl
    {
        public PlaylistControl()
        {
            this.InitializeComponent();
        }
    }
}
