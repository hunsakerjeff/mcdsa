﻿namespace DSA.Shell.Controls.Playlist
{
    public sealed partial class PersonalLibraryPlaylistControl
    {
        public PersonalLibraryPlaylistControl()
        {
            this.InitializeComponent();
        }
    }
}
