﻿namespace DSA.Shell.Controls.VisualBrowser.ControlBar.CheckInOut
{
    public sealed partial class CheckInOutControl
    {
        public CheckInOutControl()
        {
            this.InitializeComponent();
        }
    }
}
