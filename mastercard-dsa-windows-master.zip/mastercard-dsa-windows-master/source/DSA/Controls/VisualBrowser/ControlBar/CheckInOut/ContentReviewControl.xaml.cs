﻿namespace DSA.Shell.Controls.VisualBrowser.ControlBar.CheckInOut
{
    public sealed partial class ContentReviewControl
    {
        public ContentReviewControl()
        {
            this.InitializeComponent();
        }
    }
}
