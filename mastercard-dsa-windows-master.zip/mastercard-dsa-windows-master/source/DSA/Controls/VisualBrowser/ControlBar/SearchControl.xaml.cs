﻿namespace DSA.Shell.Controls.VisualBrowser.ControlBar
{
    public sealed partial class SearchControl
    {
        public SearchControl()
        {
            this.InitializeComponent();
        }
    }
}
