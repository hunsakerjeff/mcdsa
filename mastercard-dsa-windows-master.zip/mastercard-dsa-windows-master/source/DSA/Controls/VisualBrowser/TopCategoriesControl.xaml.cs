﻿namespace DSA.Shell.Controls.VisualBrowser
{
    public sealed partial class TopCategoriesControl
    {
        public TopCategoriesControl()
        {
            this.InitializeComponent();
        }
    }
}
