﻿namespace DSA.Shell.Controls.VisualBrowser
{
    public sealed partial class MainButtonsControl
    {
        public MainButtonsControl()
        {
            this.InitializeComponent();
        }
    }
}
