﻿namespace DSA.Shell.Controls.VisualBrowser
{
    public sealed partial class BrowserControl
    {
        public BrowserControl()
        {
            this.InitializeComponent();
        }
    }
}
