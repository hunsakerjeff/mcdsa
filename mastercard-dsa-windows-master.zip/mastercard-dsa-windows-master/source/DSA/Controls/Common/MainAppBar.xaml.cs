﻿namespace DSA.Shell.Controls.Common
{
    public sealed partial class MainAppBar
    {
        public MainAppBar()
        {
            InitializeComponent();
        }
    }
}
