﻿namespace DSA.Shell.Controls.Media
{
    public sealed partial class MovieControl
    {
        public MovieControl()
        {
            InitializeComponent();
        }
    }
}
