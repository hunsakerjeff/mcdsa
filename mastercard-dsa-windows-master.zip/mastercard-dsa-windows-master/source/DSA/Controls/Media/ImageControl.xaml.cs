﻿namespace DSA.Shell.Controls.Media
{
    public sealed partial class ImageControl
    {
        public ImageControl()
        {
            this.InitializeComponent();
        }
    }
}
