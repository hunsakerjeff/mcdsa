﻿namespace DSA.Shell.Controls.Media
{
    public sealed partial class AddNewPlaylistControl
    {
        public AddNewPlaylistControl()
        {
            InitializeComponent();
        }
    }
}
