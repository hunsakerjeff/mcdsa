﻿namespace DSA.Shell.Pages
{
    public sealed partial class MediaContentPage
    {
        public MediaContentPage()
        {
            InitializeComponent();
        }
    }
}
