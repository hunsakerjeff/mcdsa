﻿namespace DSA.Shell.Pages
{
    public sealed partial class VisualBrowserPage
    {
        public VisualBrowserPage()
        {
            InitializeComponent();
        }
    }
}
