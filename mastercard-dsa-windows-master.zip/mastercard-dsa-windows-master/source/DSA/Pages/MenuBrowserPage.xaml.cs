﻿namespace DSA.Shell.Pages
{
    public sealed partial class MenuBrowserPage
    {
        public MenuBrowserPage()
        {
            InitializeComponent();
        }
    }
}
