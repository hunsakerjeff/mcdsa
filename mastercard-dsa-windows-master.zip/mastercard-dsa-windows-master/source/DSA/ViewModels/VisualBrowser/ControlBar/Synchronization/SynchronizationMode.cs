﻿namespace DSA.ViewModel.VisualBrowser
{
    public enum SynchronizationMode
    {
        Full,
        Delta,
        Initial
    }
}