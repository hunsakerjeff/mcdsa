# Windows-DSA
Important VS Solution files and their purposes:

DSA/SfdcProxy/SfdcConfig.cs
 - configure SFDC Connected App OAuth ClientId and CallbackUrl here
 - CallbackUrl
   - if devices will be using SSO and/or corporate private networks, the CallbackUrl must use the App Sid
   - you can get this CallbackUrl - which is unique to package name and signing certificate, by executing: Windows.Security.Authentication.Web.WebAuthenticationBroker.GetCurrentApplicationCallbackUri();
   - the oAuth settings for these endpoints should follow the following pattern:
     
     CallbackUrl = _appCallbackUri,
     ClientId = [YOUR_CLIENT_ID],
     Options = WebAuthenticationOptions.UseCorporateNetwork,
     UseTwoParamAuthAsyncMethod = true

   - https://msdn.microsoft.com/en-us/windows/uwp/security/web-authentication-broker
   - NOTE: you should also use App Sid if you want cookies to be remembered, otherwise they are not persisted

===

DSA/Salesforce.SDK.Core/Resources/servers.xml
 - add/remove any servers here for OAuth login Choose Connection list box
 - this file is read once on first install - after that local settings are used (because users can add servers)
 - this means that this file is not meant to be updated after first use of app; if it is, an uninstall is required to pick up the changes to servers.xml; a refactor would be required to fix this

===

DSA/Salesforce.SDK.Store/Source/Pages/AccountPage.xaml
DSA/Salesforce.SDK.Store/Source/Pages/AccountPage.xaml.cs
 - add/remove buttons on OAuth login screen here - for direct links instead of having to Choose Connection
 - starting on line 169 of the xaml, add/remove buttons that direct to specific servers (like Login To Salesforce directs to login.salesforce.com)
 - the buttons require code behind for click handlers, and pull from data that originates from servers.xml; make sure your indexes are right for the click handlers
 - for uniform width of buttons, set width of smaller buttons to width of larger button (example: {Binding ElementName=LoginToSalesforce, Path=ActualWidth})

===

DSA/DSA.Model/AppSettings.cs
 - configure flags that customize app

   - EmailOnlyContentDistributionLinks - when true, the Mail button in app opens a mail with content distribution links instead of attachments

   - SyncLogsEnable - when true, logs are recorded for sync in Salesforce (requires the custom object {0}__DSA_Sync_Log__c to be part of the managed package on the platform)

   - CollectSearchTerms - when true, search terms are recorded in Salesforce (requires the custom object {0}__DSA_Search_Term__c to be part of the managed package on the platform)

   - RequireContentReviewRatingsAtCheckout - when true, each content must be reviewed at checkout before clicking done

   - AppSearchMode - when SearchMode.UseSearchPage, search results are presented on their own page.  when SearchMode.PopulatedInDropDown, results are presented in a flyout

   - PageSize - SmartSql Query page size limit used for required parameter; not really relevant because SmartSql has been extended to always set this number to the Count of the table to make sure all records are retrieved

   - ConcurrentDownloadsLimit - if Org is concerned about 25 long running API request limit, set this to 1; otherwise, it should not go higher than 5

   - RequiredStorageBufferBytes - when checking storage before beginning content or full sync operations, this gives the app a little breathing room for incidental storage requirements that might not be accounted for by the total size of the content to download or when this value is not yet known

   - SynchronizationFailedSupportEmail - email used for synchronization failure messages due to Salesforce errors

   - ReportAProblemDefaultEmail - used for report a problem email button when current mobile configurationn report a problem email is not yet known (like on first install)

   - CustomerPrefix - namespace prefix for DSA managed package

===

DSA/DSA/Package.appxmanifest
 - configure app name, signing certificate, splash screen, icons and more here
 - to change current splash screen or icons, it is enough just to replace the ones found at DSA/DSA/Assets with new versions of same dimensions (the manifest tells you the dimensions)
 - if DSA/DSA/Package.StoreAssociation.xml is still part of the repo (it really isn't necessary), the package name in the Package.appxmanifest must mach the package name here
 
===

DSA/DSA/Services/MobileConfigurationDataService.cs
 - edit GetDefaultMobileConfiguration to change logo/background image seen before mobile configuration selected (on first install after splash screen, for example)

===

DSA/DSA/App.xaml
 - another place where AppName is defined, but not used
 - where HighContrast ThemeDictionary is defined. at this point (7/7/2016) never a requirement, but makes the app at least usable when high contrast mode is on

===

DSA/DSA/Skins/MainSkin.xaml
 - ResourceDictionary where app colors/styles are defined

===

DSA/SfdcProxy/ObjectSyncDispatcher.cs
 - where sync routines are defined

*************************************

VS Solution Architecture 

SfdcMobileSDK
 - fork of Salesforce Mobile SDK for Windows 8.1 (before they switched to supporting Windows 10 only)
 - bugs fixes were required
 - modifications were made to extend functionality, such as ability to download attachment and content files

===

DSA
 - the StartUp Project
 - uses the design pattern MVVM (aided by MVVM Light Toolkit)

===

DSA.Model
 - defines the models used by the DSA and SfdcProxy projects

===

PdfViewModel
 - Microsoft c++ project for rendering PDFs used by DSA project
 - https://code.msdn.microsoft.com/windowsapps/PDF-viewer-showcase-sample-39ced1e8#content

===

SfdcProxy
 - project whose purpose is to manage the syncing of data used by DSA to/from Salesforce
 - relies on SmartStore and SmartSync from Salesforce Mobile SDK

*************************************

Gotchas!!!

Schema Changes
 - SmartStore requires indexes for each field that needs to be used in a Query; 
   it does not provide a way to add indexes (alter soup) after having created the soup in an application
 - after first installation, ADDING NEW A INDEX AND TRYING TO USE IT WILL CAUSE APP TO CRASH
 - if altering SmartStore Soup indexes is needed in an application update, either a complete uninstall of application is necessary;
   OR port the Salesforce Mobile SDK Android solution to Windows: SalesforceMobileSDK-Android/libs/SmartStore/src/com/salesforce/androidsdk/smartstore/store/AlterSoupLongOperation.java

===

Salesforce Concurrent Request Limit
 - as of 7/8/2016, the limit for concurrent requests (API calls) with a duration of 20 seconds or longer is 25
 - even if ConcurrentDownloadsLimit is set to 1, if more than 25 users try to sync at the same time and there are large files, some of them may get failures and will not be able to complete sync

*************************************

Locate Crash Logs
 - Open File Explorer
 - Select Local Disk under This PC and Navigate to Users/<YourUserName>
 - In the View menu of File Explorer, mark checked Hidden Items
 - Navigate to AppData/Local/CrashDumps
 - Look for files that start with DSA.exe -> these are the DSA crash dumps
 - When finished, return to home folder and mark unchecked Hidden Items in the View menu(optional step)
